# Atividade Prática IV — Desenvolvimento Web I

**Aluna:** Daiane Marques  
**Disciplina:** Desenvolvimento Web I  
**Instituição:** AlfaUnipac  

## Descrição

Atividade prática com foco em CSS Grid, Flexbox e Media Queries.

### Atividade 1
Portal de notícias usando CSS Grid. Layout com header, sidebar, destaque principal (2 colunas x 2 linhas), cards de notícias em 3 colunas e rodapé.

### Atividade 2
Página de restaurante responsiva com CSS Grid, Flexbox e Media Queries. Desktop em 4 colunas, tablet em 2 colunas e mobile em 1 coluna com menu vertical.

### Atividade 3
Plataforma de cursos online usando Grid + Flexbox + Media Queries juntos. Grid para estrutura geral, Flexbox para componentes internos e Media Queries para responsividade.

## Organização

```
atividade-pratica-IV/
├── atividade1/
│   ├── index.html
│   └── styles.css
├── atividade2/
│   ├── index.html
│   └── styles.css
├── atividade3/
│   ├── index.html
│   └── styles.css
└── README.md
```
